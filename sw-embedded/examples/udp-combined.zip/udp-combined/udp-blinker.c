/*
 * Copyright (c) 2016, TU Graz, Austria.
 * All rights reserved.
 *
 * EWSN Dependability Competition: Software for LED node
 *
 * \author
 * Carlo Alberto Boano <cboano@tugraz.at>
*/

/*---------------------------------------------------------------------------*/

#include <stdio.h> 
#include <stdlib.h>
#include "random.h"
#include "contiki.h"
#include "node-id.h"
#include "dev/leds.h"
#include "dev/cc2420/cc2420.h"

// Node ID settings (if defined, it checks that it is exactly this node)
#define LED_BLINKER_ID						0

// Random delay or fixed (for debugging)?
#define FIXED_DELAY							1
#define FIXED_DELAY_TIME					(CLOCK_SECOND * 2)

// Timings
#define LED_MIN_BLINKING_TIME				(CLOCK_SECOND * 2)
#define LED_RANDOM_BLINKING_TIME			(CLOCK_SECOND * 8)
#define LED_DELAY_BLINKING_TIME				20000

// Other settings
#define INITIAL_WAITING_TIME				(CLOCK_SECOND * 5)
#define SRAND_SEED							16


/*---------------------------------------------------------------------------*/

// GPIO driving
#define P23_OUT() P2DIR |= BV(3)
#define P23_IN() P2DIR &= ~BV(3)
#define P23_SEL() P2SEL &= ~BV(3)
#define P23_IS_1  (P2OUT & BV(3))
#define P23_WAIT_FOR_1() do{}while (!P23_IS_1)
#define P23_IS_0  (P2OUT & ~BV(3))
#define P23_WAIT_FOR_0() do{}while (!P23_IS_0)
#define P23_1() P2OUT |= BV(3)
#define P23_0() P2OUT &= ~BV(3)


/*---------------------------------------------------------------------------*/

// Global variables 
static uint8_t driveLED_toggle = 0;
static uint32_t driveLED_counter = 0;

// Ctimer
static struct ctimer ctimer1;
static void ctimer_blink_callback(void *ptr);


/*---------------------------------------------------------------------------*/

static void ctimer_blink_callback(void *ptr)
{ 	
    // Pin 3 and 9 -- http://sourceforge.net/p/contiki/mailman/message/18357159/
	if(driveLED_toggle==0) {		
		driveLED_toggle=1;
		P23_1();
		leds_on(LEDS_ALL);
	}
	else {
		driveLED_toggle=0;
		P23_0();
		leds_off(LEDS_ALL);
	}
	printf("[BLINKER] Change number: %lu (%u)\n", driveLED_counter, driveLED_toggle);
	driveLED_counter++;	

	#if FIXED_DELAY
		ctimer_set(&ctimer1, FIXED_DELAY_TIME, ctimer_blink_callback, NULL);
	#else
		// Some clock delay
		uint16_t random_delay = (random_rand() % LED_DELAY_BLINKING_TIME);
		clock_delay(random_delay);
	
		// Next blinking
		uint16_t blinking_time = LED_MIN_BLINKING_TIME + (random_rand() % LED_RANDOM_BLINKING_TIME);
		printf("Next blinking time in %u\n", blinking_time);
		ctimer_set(&ctimer1, blinking_time, ctimer_blink_callback, NULL);	
	#endif
}


/*---------------------------------------------------------------------------*/

PROCESS(led_process, "LED process");
AUTOSTART_PROCESSES(&led_process);
PROCESS_THREAD(led_process, ev, data)
{
	PROCESS_EXITHANDLER()
	PROCESS_BEGIN();
	
	// Better randomization
	srand(SRAND_SEED);	
	
	// Reset LEDs
	leds_off(LEDS_ALL);
	
	// Turn radio off
	cc2420_off();
	
	// Initialize LEDs
	P23_OUT();
	P23_SEL();	
		
	// Wait a bit before starting the program
	static struct etimer et;	
	etimer_set(&et, INITIAL_WAITING_TIME);
	PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&et));	

	#if NODE_ID_CHECK
	if(node_id == LED_BLINKER_ID){		
	#endif
		printf("I am the blinker. Starting in %lu seconds\n", (INITIAL_WAITING_TIME/CLOCK_SECOND));		
	
		// Make the LED blink with a given pattern
		ctimer_blink_callback(NULL);
	#if NODE_ID_CHECK
	}
	else{ 		
		printf("I will remain silent!\n");
	}
	#endif
	
	// Infinite loop
	while(1) {
		PROCESS_WAIT_EVENT();
	}

	PROCESS_END();
}

/*---------------------------------------------------------------------------*/
