#undef NETSTACK_CONF_MAC
#define NETSTACK_CONF_MAC   csma_driver // nullmac_driver

#undef NETSTACK_CONF_RDC
#define NETSTACK_CONF_RDC   contikimac_driver // nullrdc_driver

#undef NETSTACK_CONF_RDC_CHANNEL_CHECK_RATE
#define NETSTACK_CONF_RDC_CHANNEL_CHECK_RATE 8

#undef CSMA_CONF_MAX_MAC_TRANSMISSIONS
#define CSMA_CONF_MAX_MAC_TRANSMISSIONS 5

/*---------------------------------------------------------------------------*/

#undef CC2420_CONF_CCA_THRESH
#define CC2420_CONF_CCA_THRESH -43

#undef CC2420_CONF_CHANNEL
#define CC2420_CONF_CHANNEL 26

#undef NULLRDC_CONF_802154_AUTOACK
#define NULLRDC_CONF_802154_AUTOACK 1

/*---------------------------------------------------------------------------*/

#undef UIP_CONF_TCP
#define UIP_CONF_TCP 0

/*---------------------------------------------------------------------------*/

// Packet sending interval in seconds
#undef PERIOD
#define PERIOD 3

#undef TX_POWER
#define TX_POWER 31

/*---------------------------------------------------------------------------*/

//#undef RPL_CONF_INIT_LINK_METRIC
//#define RPL_CONF_INIT_LINK_METRIC 2

#define TRACK_INSERT_HBH_OPTION       1
