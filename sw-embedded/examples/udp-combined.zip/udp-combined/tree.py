#!/usr/bin/python
from dateutil import parser;
import datetime;
import itertools;
import time;
import re;
import sys;
import os;

if not os.path.exists('./tmp'):
	os.makedirs('./tmp');

print("Analyzing traces...");
sys.stdout.flush()
	
f=open('node_addresses.txt', 'r');

IP2Node={};

for line in f:
	l=line.rstrip('\n').rstrip('\r').split(':');
	IP2Node[l[1]]=l[0];	
	
f.close();


treeData=[];
tree={};
tmp=[];

#sud = range(100,113);
#nord = range(200,227);
#sud = (100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113);
#nord = (200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227);
sud = (100, 105, 111, 113, 115, 116);
nord = (206, 210, 214, 216, 219, 228);
sink = 219;

for node in itertools.chain(nord, sud):
	f=open('traces/%s.txt'%(node),'r');
	for line in f:
		l=line.rstrip('\n').rstrip('\r').split('|');		
		if re.match('PARENT', l[1]):
			t=parser.parse(l[0]);
			parent=l[1].split(' ')[1];
			try:
				if parent!='NULL':
					treeData.append((t,node,IP2Node[parent]));
				else:
					treeData.append((t,node,parent));
				tmp.append(t);
			except:
				print line;
	
	f.close();

treeData.sort();

def dotGraph(tr, tm, fname, pdf, last):
	f=open(fname,'w');
	f.write("digraph g1{\n");
	f.write("graph [label=\"%s\", fontsize=20];\n"%(tm));	
	for a in itertools.chain(nord, sud):
		if (a == sink) and (a != int(last)):
			f.write("%s [label=\"%s\", fillcolor=grey, style=filled, fontsize=20]\n"%(a,a));
		elif a == int(last):
			f.write("%s [label=\"%s\", fillcolor=red, style=filled, fontsize=20]\n"%(a,a));
		else:
			f.write("%s [label=\"%s\", fontsize=20]\n"%(a,a));
	for key, value in tr.items():
		f.write("%s->%s\n"%(key,value));

	f.write("}\n");
	f.close();
	os.system("dot -T pdf %s -o %s"%(fname,pdf));


i=1;
for x,n,p in treeData:
	tree[n]=p;
	print("Generating dot file  %s / %s"%(i,len(treeData)));
	sys.stdout.flush()
	dotGraph(tree,x,'tmp/%s.dot'%(i), 'tmp/%s.pdf'%(i), n);
	i=i+1;

# Creating a single PDF file
print("Merging %s PDF files..."%(i-1));
sys.stdout.flush()
out_str = 'pdftk '
j=1;
while j < i:
	out_str += ("tmp/%s.pdf "%(j));
	j = j+1;
out_str += "cat output tmp/temp.pdf"
os.system("%s"%(out_str));
os.system("mv tmp/temp.pdf routing_tree.pdf");
os.system("rm -R tmp");
print("... done!");
