#include <stdio.h>
#include "contiki.h"
#include "lib/random.h"
#include "sys/ctimer.h"
#include "net/ip/uip.h"
#include "net/ipv6/uip-ds6.h"
#include "net/ip/uip-udp-packet.h"
#include "dev/cc2420/cc2420.h"
#include "sys/ctimer.h"
#include "dev/light-sensor.h"
#include "node-id.h"
#include "dev/leds.h"
#include "net/rpl/rpl.h"
#include "contiki-lib.h"
#include "contiki-net.h"
#include "net/netstack.h"
#include "dev/button-sensor.h"
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define UIP_IP_BUF   ((struct uip_ip_hdr *)&uip_buf[UIP_LLH_LEN])
#define UDP_CLIENT_PORT 8765
#define UDP_SERVER_PORT 5678
#define UDP_EXAMPLE_ID  190

// Node ID settings
#define AMOUNT_CONTESTANTS_NODES 22   
static uint8_t address_routers[AMOUNT_CONTESTANTS_NODES] =  {132, 136, 139, 142, 143, 144, 145, 146, 147, 149, 151, 153, 154, 158, 200, 203, 205, 211, 214, 216};
static uint8_t reader_nodes[AMOUNT_CONTESTANTS_NODES] =     {  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1};
static uint8_t sink_nodes[AMOUNT_CONTESTANTS_NODES] =       {  0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0};

// Reader node settings
#define LED_SENSING_THRESHOLD				450
#define LED_READING_TIME					(CLOCK_SECOND / 128)

#define DEBUG_PRINTFS 1

#define DEBUG DEBUG_PRINT
#include "net/ip/uip-debug.h"

#ifndef PERIOD
#define PERIOD 60
#endif


/*---------------------------------------------------------------------------*/

// GPIO driving
#define P23_OUT() P2DIR |= BV(3)
#define P23_IN() P2DIR &= ~BV(3)
#define P23_SEL() P2SEL &= ~BV(3)
#define P23_IS_1  (P2OUT & BV(3))
#define P23_WAIT_FOR_1() do{}while (!P23_IS_1)
#define P23_IS_0  (P2OUT & ~BV(3))
#define P23_WAIT_FOR_0() do{}while (!P23_IS_0)
#define P23_1() P2OUT |= BV(3)
#define P23_0() P2OUT &= ~BV(3)


/*---------------------------------------------------------------------------*/

static struct uip_udp_conn *client_conn;
static struct uip_udp_conn *server_conn;
static uip_ipaddr_t server_ipaddr;
static void send_packet(void *ptr);

// Ctimer
static struct ctimer ctimer1;
static void ctimer_readled_callback(void *ptr);

// Role
uint8_t am_i_client = 0;
uint8_t am_i_reader = 0;
uint8_t am_i_sink = 0;
	

/*---------------------------------------------------------------------------*/

// LED READING 
struct led_message{
	uint32_t sequence_number;	
	uint8_t status;	
};

static uint8_t readLED_current_status = 0;
static uint32_t readLED_counter = 0;


/*---------------------------------------------------------------------------*/

static void ctimer_readled_callback(void *ptr)
{ 			
	// Read current light sensors
	uint16_t raw_light_PAR = light_sensor.value(LIGHT_SENSOR_PHOTOSYNTHETIC);
	uint16_t raw_light_TSR = light_sensor.value(LIGHT_SENSOR_TOTAL_SOLAR);

	// Derive if LED is ON or OFF
	uint8_t readLED_new_status = 0;
	if((raw_light_PAR > LED_SENSING_THRESHOLD) || (raw_light_TSR > LED_SENSING_THRESHOLD)){
		readLED_new_status = 1;
	}
	
	// Was there a change?
	if(readLED_current_status != readLED_new_status){
		
		// Update status and counter
		readLED_current_status = readLED_new_status;
		readLED_counter++;
		
		// Send a message to the sink
		send_packet(NULL);		

		// Update LEDs
		if(readLED_current_status == 1){
			leds_on(LEDS_ALL);
		}
		else{
			leds_off(LEDS_ALL);
		}
		
		#if DEBUG_PRINTFS
			printf("LED cha	nge number %lu (%u) --- %u, %u, %u\n", readLED_counter, readLED_current_status, raw_light_PAR, raw_light_TSR, LED_SENSING_THRESHOLD);
		#endif
	}
	else{
		// Nothing to do
		// printf("No LED change: %u, %u, %u\n", raw_light_PAR, raw_light_TSR, LED_SENSING_THRESHOLD);
	}
	
	ctimer_set(&ctimer1, LED_READING_TIME, ctimer_readled_callback, NULL);		
}


/*---------------------------------------------------------------------------*/
static void
tcpip_handler(void)
{  
  if(am_i_sink == 1){
	if(uip_newdata()) {
	struct led_message mesg; 
    memcpy(&mesg, uip_appdata, sizeof(struct led_message));
    printf("DATA received from %d.%d: %lu, %u\n",  UIP_IP_BUF->srcipaddr.u8[sizeof(UIP_IP_BUF->srcipaddr.u8) - 1], UIP_IP_BUF->srcipaddr.u8[sizeof(UIP_IP_BUF->srcipaddr.u8) - 2], mesg.sequence_number, mesg.status);
	// Drive LEDs accordingly
	if(mesg.status == 1) {	
		P23_1();
		leds_on(LEDS_ALL);				
	}
	else {
		P23_0();
		leds_off(LEDS_ALL);			
	}	
  }
  }
  else{
	if(uip_newdata()) {
		struct led_message mesg; 
		memcpy(&mesg, uip_appdata, sizeof(struct led_message));
		#if DEBUG_PRINTFS
			printf("DATA received from %d.%d: %lu, %u\n",  UIP_IP_BUF->srcipaddr.u8[sizeof(UIP_IP_BUF->srcipaddr.u8) - 1], UIP_IP_BUF->srcipaddr.u8[sizeof(UIP_IP_BUF->srcipaddr.u8) - 2], mesg.sequence_number, mesg.status);
		#endif 
	} 
  }
}


/*---------------------------------------------------------------------------*/
static void
send_packet(void *ptr)
{
  struct led_message msg;  
  msg.sequence_number = readLED_counter; 
  msg.status = readLED_current_status; 	
    
  // printf("DATA send to %d.%d: %lu, %u'\n", server_ipaddr.u8[sizeof(server_ipaddr.u8) - 1], server_ipaddr.u8[sizeof(server_ipaddr.u8) - 2], msg.sequence_number, msg.status);
  uip_udp_packet_sendto(client_conn, &msg, sizeof(struct led_message), &server_ipaddr, UIP_HTONS(UDP_SERVER_PORT));
}
/*---------------------------------------------------------------------------*/
static void
print_local_addresses(void)
{
  int i;
  uint8_t state;
  if(am_i_sink == 1){
	PRINTF("Client IPv6 addresses: ");
	for(i = 0; i < UIP_DS6_ADDR_NB; i++) {
		state = uip_ds6_if.addr_list[i].state;
		if(uip_ds6_if.addr_list[i].isused &&
		(state == ADDR_TENTATIVE || state == ADDR_PREFERRED)) {
			PRINT6ADDR(&uip_ds6_if.addr_list[i].ipaddr);
			PRINTF("\n");
			/* hack to make address "final" */
			if (state == ADDR_TENTATIVE) {
				uip_ds6_if.addr_list[i].state = ADDR_PREFERRED;
			}
		}
	}
  }
  else{
	PRINTF("Server IPv6 addresses: ");
    for(i = 0; i < UIP_DS6_ADDR_NB; i++) {
		state = uip_ds6_if.addr_list[i].state;
		if(state == ADDR_TENTATIVE || state == ADDR_PREFERRED) {
			PRINT6ADDR(&uip_ds6_if.addr_list[i].ipaddr);
			PRINTF("\n");
			/* hack to make address "final" */
			if (state == ADDR_TENTATIVE) {
				uip_ds6_if.addr_list[i].state = ADDR_PREFERRED;
			}
		}
	}
  }	  
}


/*---------------------------------------------------------------------------*/
static void
set_global_address(void)
{
  uip_ipaddr_t ipaddr;

  uip_ip6addr(&ipaddr, 0xaaaa, 0, 0, 0, 0, 0, 0, 0);
  uip_ds6_set_addr_iid(&ipaddr, &uip_lladdr);
  uip_ds6_addr_add(&ipaddr, 0, ADDR_AUTOCONF);

/* The choice of server address determines its 6LoPAN header compression.
 * (Our address will be compressed Mode 3 since it is derived from our link-local address)
 * Obviously the choice made here must also be selected in udp-server.c.
 *
 * For correct Wireshark decoding using a sniffer, add the /64 prefix to the 6LowPAN protocol preferences,
 * e.g. set Context 0 to aaaa::.  At present Wireshark copies Context/128 and then overwrites it.
 * (Setting Context 0 to aaaa::1111:2222:3333:4444 will report a 16 bit compressed address of aaaa::1111:22ff:fe33:xxxx)
 *
 * Note the IPCMV6 checksum verification depends on the correct uncompressed addresses.
 */
 
#if 0
/* Mode 1 - 64 bits inline */
   uip_ip6addr(&server_ipaddr, 0xaaaa, 0, 0, 0, 0, 0, 0, 1);
#elif 1
/* Mode 2 - 16 bits inline */
  uip_ip6addr(&server_ipaddr, 0xaaaa, 0, 0, 0, 0, 0x00ff, 0xfe00, 1);
#else
/* Mode 3 - derived from server link-local (MAC) address */
  uip_ip6addr(&server_ipaddr, 0xaaaa, 0, 0, 0, 0x0250, 0xc2ff, 0xfea8, 0xcd1a); //redbee-econotag
#endif
}
/*---------------------------------------------------------------------------*/
PROCESS(udp_combined_process, "UDP combined process");
AUTOSTART_PROCESSES(&udp_combined_process);
PROCESS_THREAD(udp_combined_process, ev, data)
{
	PROCESS_BEGIN();
	PROCESS_PAUSE();
	
	// Initialize LEDs / GPIOs
	P23_OUT();
	P23_SEL();	
	P23_0();
	leds_off(LEDS_ALL);	

	// Radio settings
	cc2420_set_channel(CC2420_CONF_CHANNEL);
	cc2420_set_txpower(TX_POWER);
	printf("Node id: %u, 802.15.4 channel: %u, TX pow: %u\n", node_id, cc2420_get_channel(), cc2420_get_txpower());

	// Find the configuration for this node
	uint8_t temp = 0;
	for(temp=0; temp<AMOUNT_CONTESTANTS_NODES; temp++){
		// If I am a designated router
		if(node_id == address_routers[temp]){
			am_i_client = 1;
			am_i_reader = reader_nodes[temp];
			am_i_sink = sink_nodes[temp];
			break;
		}
	}

	// SINK
	if(am_i_sink == 1){
		uip_ipaddr_t ipaddr;
		struct uip_ds6_addr *root_if;
		SENSORS_ACTIVATE(button_sensor);
		PRINTF("UDP server started\n");

		#if UIP_CONF_ROUTER
		/* The choice of server address determines its 6LoPAN header compression.
		 * Obviously the choice made here must also be selected in udp-client.c.
		 *
		 * For correct Wireshark decoding using a sniffer, add the /64 prefix to the 6LowPAN protocol preferences,
		 * e.g. set Context 0 to aaaa::.  At present Wireshark copies Context/128 and then overwrites it.
		 * (Setting Context 0 to aaaa::1111:2222:3333:4444 will report a 16 bit compressed address of aaaa::1111:22ff:fe33:xxxx)
		 * Note Wireshark's IPCMV6 checksum verification depends on the correct uncompressed addresses.
		 */
		 
		#if 0
		/* Mode 1 - 64 bits inline */
		   uip_ip6addr(&ipaddr, 0xaaaa, 0, 0, 0, 0, 0, 0, 1);
		#elif 1
		/* Mode 2 - 16 bits inline */
		  uip_ip6addr(&ipaddr, 0xaaaa, 0, 0, 0, 0, 0x00ff, 0xfe00, 1);
		#else
		/* Mode 3 - derived from link local (MAC) address */
		  uip_ip6addr(&ipaddr, 0xaaaa, 0, 0, 0, 0, 0, 0, 0);
		  uip_ds6_set_addr_iid(&ipaddr, &uip_lladdr);
		#endif

		uip_ds6_addr_add(&ipaddr, 0, ADDR_MANUAL);
		root_if = uip_ds6_addr_lookup(&ipaddr);
		if(root_if != NULL) {
			rpl_dag_t *dag;
			dag = rpl_set_root(RPL_DEFAULT_INSTANCE,(uip_ip6addr_t *)&ipaddr);
			uip_ip6addr(&ipaddr, 0xaaaa, 0, 0, 0, 0, 0, 0, 0);
			rpl_set_prefix(dag, &ipaddr, 64);
			PRINTF("created a new RPL dag\n");
		} else {
			PRINTF("failed to create a new RPL DAG\n");
		}
		#endif /* UIP_CONF_ROUTER */
		  
		print_local_addresses();

		// The data sink runs with a 100% duty cycle in order to ensure high packet reception rates
		NETSTACK_MAC.off(1);

		server_conn = udp_new(NULL, UIP_HTONS(UDP_CLIENT_PORT), NULL);
		if(server_conn == NULL) {
			PRINTF("No UDP connection available, exiting the process!\n");
			PROCESS_EXIT();
		}
		udp_bind(server_conn, UIP_HTONS(UDP_SERVER_PORT));

		PRINTF("Created a server connection with remote address ");
		PRINT6ADDR(&server_conn->ripaddr);
		PRINTF(" local/remote port %u/%u\n", UIP_HTONS(server_conn->lport), UIP_HTONS(server_conn->rport));

		while(1) {
			PROCESS_YIELD();
			if(ev == tcpip_event) {
				tcpip_handler();
			} 
			else if (ev == sensors_event && data == &button_sensor) {
				PRINTF("Initiaing global repair\n");
				rpl_repair_root(RPL_DEFAULT_INSTANCE);
			}
		}
	}
	// CLIENT
	else 
	{
		if(am_i_client == 1){
			
			set_global_address();
			PRINTF("UDP client process started\n");
			print_local_addresses();
			
			// New connection with remote host
			client_conn = udp_new(NULL, UIP_HTONS(UDP_SERVER_PORT), NULL); 
			if(client_conn == NULL) {
				PRINTF("No UDP connection available, exiting the process!\n");
				PROCESS_EXIT();
			}
			udp_bind(client_conn, UIP_HTONS(UDP_CLIENT_PORT)); 

			PRINTF("Created a connection with the server ");
			PRINT6ADDR(&client_conn->ripaddr);
			PRINTF(" local/remote port %u/%u\n", UIP_HTONS(client_conn->lport), UIP_HTONS(client_conn->rport));

			if(am_i_reader == 1){
				printf("I am the reader\n");
				SENSORS_ACTIVATE(light_sensor);
				ctimer_readled_callback(NULL);
			}
			else{
				printf("I am a forwarder\n");
				leds_on(LEDS_BLUE);
			}
		}
		else{
			printf("I am not supposed to be part of the network and I will remain silent!\n");
			cc2420_off();
		}
	}
	
	while(1) {
		PROCESS_YIELD();
		if(ev == tcpip_event) {
			tcpip_handler();
		}
	}

	PROCESS_END();
}
/*---------------------------------------------------------------------------*/
